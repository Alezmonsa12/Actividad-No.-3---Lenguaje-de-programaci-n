// server.js
const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const PORT = 3000;

// Configuraciones
app.use(bodyParser.json());
app.use(cors());

// Configuración de conexión a MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',          //  Usuario de MySQL
    password: 'Pecosa18',    // Contraseña de MySQL
    database: 'formulario_db'     // Nombre de la base de datos
});

// Conexión a la base de datos
db.connect(err => {
    if (err) {
        console.error('Error conectando a la base de datos:', err);
        return;
    }
    console.log('Conectado a la base de datos MySQL.');
});

// Ruta para procesar la solicitud de cotización
app.post('/api/solicitud-cotizacion', (req, res) => {
    //Recibe lso dartos del formulario
    const { name, ciudad, direccion, celular, productos } = req.body;

    // Insertar la cotización principal (sin productos)
    const sqlCotizacion = 'INSERT INTO cotizaciones (nombre, ciudad, direccion, celular) VALUES (?, ?, ?, ?)';
    db.query(sqlCotizacion, [name, ciudad, direccion, celular], (err, result) => {
        if (err) {
            console.error('Error al insertar datos de la cotización:', err);
            return res.status(500).json({ message: 'Error al guardar la cotización.' });
        }

        // Obtener el ID de la cotización recién insertada
        const cotizacionId = result.insertId;

        // Verificar si hay productos y prepararlos para la inserción
        if (productos && productos.length > 0) {
            const sqlProductos = 'INSERT INTO productos_cotizacion (cotizacion_id, nombre, precio_unitario) VALUES ?';
            
            // Preparar los datos de los productos para la inserción múltiple
            const productosValues = productos.map(producto => [cotizacionId, producto.nombre, producto.precio]);

            // Insertar los productos asociados a la cotización
            db.query(sqlProductos, [productosValues], (err) => {
                if (err) {
                    console.error('Error al insertar productos:', err);
                    return res.status(500).json({ message: 'Error al guardar los productos de la cotización.' });
                }

                res.status(200).json({ message: 'Cotización y productos guardados exitosamente.' });
            });
        } else {
            res.status(200).json({ message: 'Cotización guardada sin productos.' });
        }
    });
});

app.get('/api/obtener-cotizaciones', (req, res) => {
    const sql = `
    SELECT c.id AS cotizacionId, c.nombre, c.ciudad, c.direccion, c.celular,
           p.nombre AS productoNombre, p.precio_unitario
    FROM cotizaciones AS c
    LEFT JOIN productos_cotizacion AS p ON c.id = p.cotizacion_id
    ORDER BY c.id;
`;
    db.query(sql, (err, results) => {
        if (err) {
            console.error('Error al obtener cotizaciones:', err);
            return res.status(500).json({ message: 'Error al obtener cotizaciones.' });
        }

        // Agrupar los datos de cada cotización con sus productos
        const cotizaciones = results.reduce((acc, row) => {
            const cotizacionId = row.cotizacionId;
            
            if (!acc[cotizacionId]) {
                acc[cotizacionId] = {
                    cotizacionId,
                    nombre: row.nombre,
                    ciudad: row.ciudad,
                    direccion: row.direccion,
                    celular: row.celular,
                    fecha: row.fecha,
                    productos: []
                };
            }
            
            if (row.productoNombre) {
                acc[cotizacionId].productos.push({
                    nombre: row.productoNombre,
                    precio: row.precio_unitario
                });
            }
            
            return acc;
        }, {});

        res.status(200).json(Object.values(cotizaciones));
    });
});

// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`Servidor escuchando en http://localhost:${PORT}`);
});
